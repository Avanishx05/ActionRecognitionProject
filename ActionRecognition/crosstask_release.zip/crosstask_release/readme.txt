tasks_primary.txt -- list of 18 primary tasks in the following format:
Task ID
Task name
URL of corresponding WikiHow page
Number of steps
Ordered list of comma-separated steps of the task

tasks_primary.txt -- list of the related tasks in the same format.

videos.csv -- list of videos in format <Task ID>,<YouTube video ID>,<URL>

annotations/<task id>_<video id>.csv -- annotated temporal segments of ground truth steps in the form <number of step>,<start in seconds>,<end in seconds>
